export const services = [
  {
    "name": "Microneedling facial",
    "description": "Estimula la renovación de la piel y la producción de colágeno, ayudando a mejorar su textura, apariencia y luminosidad.",
    "category": "facial"
  },
  {
    "name": "Higiene facial",
    "description": "Limpieza personalizada que elimina impurezas, exceso de grasa y células muertas para mantener una piel limpia y saludable.",
    "category": "facial"
  },
  {
    "name": "Tratamiento de grasa localizada",
    "description": "Alternativas médico-estéticas dirigidas a tratar depósitos de grasa en zonas específicas del cuerpo, previa valoración médica.",
    "category": "corporal"
  },
  {
    "name": "Toxina botulínica",
    "description": "Tratamiento que suaviza temporalmente las líneas de expresión mediante la relajación controlada de músculos específicos.",
    "category": "facial"
  },
  {
    "name": "Bioestimulación con PRP",
    "description": "Utiliza el plasma rico en plaquetas del propio paciente para favorecer los procesos naturales de regeneración de la piel.",
    "category": "facial"
  },
  {
    "name": "Peelings químicos",
    "description": "Favorecen la renovación cutánea y ayudan a mejorar manchas, textura irregular y otras alteraciones superficiales de la piel.",
    "category": "facial"
  },
  {
    "name": "Inductores de colágeno",
    "description": "Estimulan la producción natural de colágeno, contribuyendo progresivamente a mejorar la firmeza y calidad de la piel.",
    "category": "facial"
  },
  {
    "name": "Mesoterapia facial",
    "description": "Aplicación de activos seleccionados según las necesidades de la piel para complementar su hidratación y mejorar su apariencia.",
    "category": "facial"
  },
  {
    "name": "Hydrafacial",
    "description": "Limpieza facial avanzada que combina exfoliación, extracción de impurezas e hidratación para una piel de aspecto más fresco y luminoso.",
    "category": "facial"
  },
  {
    "name": "Microdermoabrasión",
    "description": "Exfoliación mecánica que ayuda a retirar células superficiales y mejorar la suavidad y textura de la piel.",
    "category": "facial"
  },
  {
    "name": "Tratamiento de melasma y manchas",
    "description": "Protocolos personalizados orientados a mejorar las alteraciones de pigmentación y favorecer un tono de piel más uniforme.",
    "category": "dermatologia"
  },
  {
    "name": "Tratamiento dermatológico del acné",
    "description": "Evaluación y manejo personalizado del acné, enfocado en controlar las lesiones y mejorar la salud de la piel.",
    "category": "dermatologia"
  },
  {
    "name": "Tratamiento médico de estrías",
    "description": "Procedimiento orientado a mejorar la apariencia de las estrías mediante técnicas de estimulación de colágeno y regeneración cutánea. Ayuda a mejorar la textura, elasticidad y uniformidad de la piel, según el tipo y evolución de las estrías.",
    "category": "corporal"
  },
  {
    "name": "Escleroterapia de várices y arañas vasculares",
    "description": "Tratamiento médico mínimamente invasivo que consiste en aplicar una solución esclerosante en vasos sanguíneos superficiales seleccionados, favoreciendo su cierre progresivo y mejorando la apariencia de arañas vasculares y pequeñas venas dilatadas.",
    "category": "corporal"
  },
  {
    "name": "Tratamientos despigmentantes corporales",
    "description": "Protocolos especializados para mejorar manchas e hiperpigmentaciones en diferentes zonas del cuerpo, mediante activos despigmentantes y técnicas dermatológicas que favorecen una piel más uniforme y luminosa.",
    "category": "corporal"
  },
  {
    "name": "Tratamiento para eliminación de papada",
    "description": "Procedimiento médico estético dirigido a reducir la acumulación de grasa localizada en la región submentoniana (debajo del mentón), buscando mejorar el contorno mandibular y la definición del perfil facial. La técnica se selecciona según la valoración anatómica del paciente.",
    "category": "corporal"
  },
  {
    "name": "Electrocauterización de verrugas y lesiones cutáneas benignas",
    "description": "Procedimiento médico que utiliza energía eléctrica para tratar determinadas lesiones superficiales de la piel, como algunas verrugas y otras lesiones benignas. Requiere valoración previa para establecer el diagnóstico y determinar si la cauterización es el tratamiento adecuado.",
    "category": "dermatologia"
  },
  {
    "name": "Tratamiento de ojeras",
    "description": "Tratamiento especializado que ayuda a mejorar la apariencia de las ojeras, aportando hidratación, luminosidad y revitalización al contorno de los ojos.",
    "category": "facial"
  },
  {
    "name": "Tratamiento de alopecias",
    "description": "Valoración de la caída del cabello y del cuero cabelludo para orientar las opciones de atención según cada caso.",
    "category": "dermatologia"
  },
  {
    "name": "Consultas dermatológicas",
    "description": "Un espacio para consultar sobre la salud de tu piel, recibir una valoración y conversar sobre las opciones de atención.",
    "category": "dermatologia"
  }
]
