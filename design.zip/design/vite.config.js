import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'
import { fileURLToPath } from 'node:url'

// https://vite.dev/config/
export default defineConfig({
  base: '/design/',
  plugins: [react()],
  build: {
    outDir: 'dist/design',
    rollupOptions: {
      input: {
        home: fileURLToPath(new URL('./index.html', import.meta.url)),
        services: fileURLToPath(new URL('./servicios/index.html', import.meta.url)),
        results: fileURLToPath(new URL('./resultados/index.html', import.meta.url)),
      },
    },
  },
})
