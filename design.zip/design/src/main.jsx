import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { MotionConfig } from 'motion/react'
import './index.css'
import App from './App.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <MotionConfig reducedMotion="user">
      <App
        isServicesPage={window.location.pathname.startsWith(`${import.meta.env.BASE_URL}servicios/`)}
        isResultsPage={window.location.pathname.startsWith(`${import.meta.env.BASE_URL}resultados/`)}
      />
    </MotionConfig>
  </StrictMode>,
)
