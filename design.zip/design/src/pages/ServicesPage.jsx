import Hero from '../components/Hero'
import FaqItem from '../components/FaqItem'
import TreatmentIcon from '../components/TreatmentIcon'
import { services } from '../data/services'
import clinicCare from '../assets/clinic/featured-treatment.webp'

const categories = [
  { id: 'facial', name: 'Cuidado facial', icon: 'cleansing', description: 'Opciones para el cuidado, la textura y la apariencia de tu piel.' },
  { id: 'corporal', name: 'Tratamientos corporales', icon: 'body', description: 'Atención de zonas específicas del cuerpo, según tu valoración médica.' },
  { id: 'dermatologia', name: 'Dermatología clínica', icon: 'microneedling', description: 'Valoración de la salud de la piel y del cuero cabelludo.' },
]

export default function ServicesPage() {
  return (
    <>
      <Hero image={clinicCare} width={1200} height={1178} titleId="services-hero-title" className="services-hero photo-hero"
        eyebrow="Lúmina · Nuestros servicios"
        title={<>Un cuidado que comienza por conocerte.</>}
        description="Medicina estética y dermatología clínica en León, Nicaragua. Conoce nuestras opciones y consulta por una valoración profesional."
        actions={<a className="button button-primary" href="https://wa.me/50558811397">Consultar por WhatsApp <span aria-hidden="true">↗</span></a>}
      />
      <section className="services-section container section-space" id="servicios" aria-labelledby="services-title">
        <div className="section-intro">
          <div><p className="eyebrow">Sabiduría en cada proceso</p><h2 id="services-title">Encuentra el cuidado<br />que buscas.</h2></div>
          <p>Explora cada categoría y abre un tratamiento para conocer más. La doctora te orientará sobre las opciones adecuadas para ti.</p>
        </div>
        <nav className="service-category-nav" aria-label="Categorías de servicios">
          {categories.map(({ id, name }) => <a key={id} href={`#${id}`}>{name} <span aria-hidden="true">↓</span></a>)}
        </nav>
        {categories.map(({ id, name, icon, description }, index) => (
          <section className="service-category" id={id} key={id} aria-labelledby={`${id}-title`}>
            <div className="service-category-heading">
              <span className="service-category-number">0{index + 1}</span>
              <TreatmentIcon treatment={icon} />
              <h2 id={`${id}-title`}>{name}</h2>
              <p>{description}</p>
            </div>
            <div className="service-category-list">
              {services.filter((service) => service.category === id).map(({ name: treatment, description: detail }) => (
                <FaqItem key={treatment} question={treatment} className="service-details">
                  <p>{detail}</p>
                  <a className="service-card-contact" href={`https://wa.me/50558811397?text=${encodeURIComponent(`Hola, quisiera información sobre ${treatment}.`)}`} aria-label={`Consultar por WhatsApp sobre ${treatment}`}>
                    Consultar por WhatsApp <span aria-hidden="true">↗</span>
                  </a>
                </FaqItem>
              ))}
            </div>
          </section>
        ))}
        <a className="text-link services-results-link" href={`${import.meta.env.BASE_URL}resultados/`}>Explorar los resultados de tratamientos <span aria-hidden="true">↗</span></a>
      </section>
    </>
  )
}
