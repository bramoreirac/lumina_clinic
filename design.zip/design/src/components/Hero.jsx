import useMotionPreference from './useMotionPreference'
import { motion } from 'motion/react'
import { entrance } from './motionSettings'

export default function Hero({ image, width, height, title, titleId, eyebrow, byline, description, actions, className = '' }) {
  const reducedMotion = useMotionPreference()
  return (
    <section className={`clinic-hero ${className}`} id="inicio" aria-labelledby={titleId}>
      {image && <motion.img className="hero-photo" src={image} alt="" width={width} height={height} fetchPriority="high"
        initial={reducedMotion ? false : { opacity: 0.4 }} animate={{ opacity: 1 }} transition={{ duration: reducedMotion ? 0 : 0.4 }} />}
      <div className="container clinic-hero-inner">
        {eyebrow && <p className="hero-eyebrow">{eyebrow}</p>}
        <motion.h1 id={titleId} {...entrance(reducedMotion, 0.08)}>{title}</motion.h1>
        <div className="hero-rule" aria-hidden="true"></div>
        <motion.p {...entrance(reducedMotion, 0.18)}>{description}</motion.p>
        {byline && <p className="hero-byline">{byline}</p>}
        <motion.div className="hero-actions" {...entrance(reducedMotion, 0.28)}>{actions}</motion.div>
      </div>
    </section>
  )
}
